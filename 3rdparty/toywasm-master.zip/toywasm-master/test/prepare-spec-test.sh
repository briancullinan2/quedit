#! /bin/sh

set -e

WAST2JSON=${WAST2JSON:-wast2json}

fetch_spec()
{
    SPEC_DIR=$1
    REPO=$2
    REF=$3
    if test -d ${SPEC_DIR}; then
        return
    fi
    mkdir "${SPEC_DIR}"
    git -C "${SPEC_DIR}" init
    git -C "${SPEC_DIR}" fetch --depth 1 ${REPO} ${REF}
    git -C "${SPEC_DIR}" checkout FETCH_HEAD
}

compile()
{
    TEST_DIR=$1
    shift 1
    while read WAST; do
        D=${TEST_DIR}/$(dirname ${WAST})
        mkdir -p ${D}
        ${WAST2JSON} --enable-all "$@" -o ${TEST_DIR}/${WAST%%.wast}.json ${SPEC_DIR}/${WAST}
    done
}

${WAST2JSON} --version

# Note: --no-check for https://github.com/WebAssembly/wabt/issues/2201
fetch_spec .spec https://github.com/WebAssembly/spec 28c3c7a5c257fa782852e7cf9729d21d0038df6a
(cd ${SPEC_DIR} && find test -name "*.wast") | compile . --no-check

fetch_spec .spec-threads https://github.com/WebAssembly/threads 09f2831349bf409187abb6f7868482a8079f2264
# Note: we don't have the test harness necessary for threads.wast
(cd .spec-threads && find test -name "atomic.wast") | compile threads

fetch_spec .spec-tail-call https://github.com/WebAssembly/tail-call 6f44ca27af411a0f6bc4e07520807d7adfc0de88
(cd .spec-tail-call && find test -name "return_call*.wast") | compile tail-call

# https://github.com/WebAssembly/multi-memory/pull/46
fetch_spec .spec-multi-memory https://github.com/WebAssembly/multi-memory cf8b5aa27257311b8eac80ae83f4ba22ee308064
(cd .spec-multi-memory && find test \
-name "load.wast" -o \
-name "store.wast" -o \
-name "memory_size.wast" -o \
-name "memory_grow.wast" -o \
-path "*/multi-memory/*.wast" -a ! -name "memory_copy1.wast") \
| compile multi-memory

fetch_spec .spec-extended-const https://github.com/WebAssembly/extended-const 8d4f6aa2b00a8e7c0174410028625c6a176db8a1
(cd .spec-extended-const && find test \
-name "data.wast" -o \
-name "elem.wast" -o \
-name "global.wast") | compile extended-const

# note: edb9c5b5e1ba9895c206b009429fa8ed72b16a9e doesn't work with
# the current wabt as of today
fetch_spec .spec-custom-page-sizes https://github.com/WebAssembly/custom-page-sizes 2147a64be7b996ce15074ced6906363f02e94fdd
(cd .spec-custom-page-sizes && find test \
-path "*/custom-page-sizes/*.wast" -a ! -name "memory_max_i64.wast") \
| compile custom-page-sizes

# REVISIT: wabt (wast2json) doesn't implement the latest exception-handling
# yet. https://github.com/WebAssembly/wabt/issues/2348
#fetch_spec .spec-exception-handling https://github.com/WebAssembly/exception-handling d12346cf9a10ddeeef0fcf0c08819755e1a4ac4a
#(cd .spec-exception-handling && find test \
#-name "try_catch.wast" -o \
#-name "try_delegate.wast" -o \
#-name "throw.wast" -o \
#-name "rethrow.wast") | compile exception-handling
