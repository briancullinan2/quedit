// The `cmap` table stores the mappings from characters to glyphs.
// https://www.microsoft.com/typography/OTSPEC/cmap.htm

import check from '../check.mjs';
import parse from '../parse.mjs';
import table from '../table.mjs';
import { eightBitMacEncodings } from '../types.mjs';
import { getEncoding } from '../tables/name.mjs';

function parseCmapTableFormat0(cmap, p, platformID, encodingID) {
    // Length in bytes of the index map
    cmap.length = p.parseUShort();
    // see https://developer.apple.com/fonts/TrueType-Reference-Manual/RM06/Chap6name.html
    // section "Macintosh Language Codes"
    cmap.language = p.parseUShort() - 1;

    const indexMap = p.parseByteList(cmap.length);
    const glyphIndexMap = Object.assign({}, indexMap);
    const encoding = getEncoding(platformID, encodingID, cmap.language);
    const decodingTable = eightBitMacEncodings[encoding];
    for (let i = 0; i < decodingTable.length; i++) {
        glyphIndexMap[decodingTable.charCodeAt(i)] = indexMap[0x80 + i];
    }
    cmap.glyphIndexMap = glyphIndexMap;
}

function parseCmapTableFormat12or13(cmap, p, format) {
    //Skip reserved.
    p.parseUShort();

    // Length in bytes of the sub-tables.
    cmap.length = p.parseULong();
    cmap.language = p.parseULong();

    let groupCount;
    cmap.groupCount = groupCount = p.parseULong();
    cmap.glyphIndexMap = {};

    for (let i = 0; i < groupCount; i += 1) {
        const startCharCode = p.parseULong();
        const endCharCode = p.parseULong();
        let startGlyphId = p.parseULong();

        for (let c = startCharCode; c <= endCharCode; c += 1) {
            cmap.glyphIndexMap[c] = startGlyphId;
            if (format === 12) {
                startGlyphId++;
            }
        }
    }
}

function parseCmapTableFormat4(cmap, p, data, start, offset) {
    // Length in bytes of the sub-tables.
    cmap.length = p.parseUShort();
    cmap.language = p.parseUShort();

    // segCount is stored x 2.
    let segCount;
    cmap.segCount = segCount = p.parseUShort() >> 1;

    // Skip searchRange, entrySelector, rangeShift.
    p.skip('uShort', 3);

    // The "unrolled" mapping from character codes to glyph indices.
    cmap.glyphIndexMap = {};
    const endCountParser = new parse.Parser(data, start + offset + 14);
    const startCountParser = new parse.Parser(data, start + offset + 16 + segCount * 2);
    const idDeltaParser = new parse.Parser(data, start + offset + 16 + segCount * 4);
    const idRangeOffsetParser = new parse.Parser(data, start + offset + 16 + segCount * 6);
    let glyphIndexOffset = start + offset + 16 + segCount * 8;
    for (let i = 0; i < segCount - 1; i += 1) {
        let glyphIndex;
        const endCount = endCountParser.parseUShort();
        const startCount = startCountParser.parseUShort();
        const idDelta = idDeltaParser.parseShort();
        const idRangeOffset = idRangeOffsetParser.parseUShort();
        for (let c = startCount; c <= endCount; c += 1) {
            if (idRangeOffset !== 0) {
                // The idRangeOffset is relative to the current position in the idRangeOffset array.
                // Take the current offset in the idRangeOffset array.
                glyphIndexOffset = (idRangeOffsetParser.offset + idRangeOffsetParser.relativeOffset - 2);

                // Add the value of the idRangeOffset, which will move us into the glyphIndex array.
                glyphIndexOffset += idRangeOffset;

                // Then add the character index of the current segment, multiplied by 2 for USHORTs.
                glyphIndexOffset += (c - startCount) * 2;
                glyphIndex = parse.getUShort(data, glyphIndexOffset);
                if (glyphIndex !== 0) {
                    glyphIndex = (glyphIndex + idDelta) & 0xFFFF;
                }
            } else {
                glyphIndex = (c + idDelta) & 0xFFFF;
            }

            cmap.glyphIndexMap[c] = glyphIndex;
        }
    }
}

function parseCmapTableFormat14(cmap, p) {
    const varSelectorList = {};

    p.skip('uLong'); // skip length

    const numVarSelectorRecords = p.parseULong();

    for(let i = 0; i < numVarSelectorRecords; i += 1) {
        const varSelector = p.parseUInt24();
        const varSelectorRecord = {
            varSelector
        };

        const defaultUVSOffset = p.parseOffset32();
        const nonDefaultUVSOffset = p.parseOffset32();
        
        const currentOffset = p.relativeOffset;

        if ( defaultUVSOffset ) {
            p.relativeOffset = defaultUVSOffset;
            varSelectorRecord.defaultUVS = p.parseStruct({
                ranges: function() {
                    return p.parseRecordList32({
                        startUnicodeValue: p.parseUInt24,
                        additionalCount: p.parseByte
                    });
                }
            });
        }

        if ( nonDefaultUVSOffset ) {
            p.relativeOffset = nonDefaultUVSOffset;
            varSelectorRecord.nonDefaultUVS = p.parseStruct({
                uvsMappings: function() {
                    const map = {};
                    const list = p.parseRecordList32({
                        unicodeValue: p.parseUInt24,
                        glyphID: p.parseUShort
                    });
                    
                    for(let i = 0; i < list.length; i += 1) {
                        map[list[i].unicodeValue] = list[i];
                    }

                    return map;
                }
            });
        }

        varSelectorList[varSelector] = varSelectorRecord;

        p.relativeOffset = currentOffset;
    }

    cmap.varSelectorList = varSelectorList;
}

// Parse the `cmap` table. This table stores the mappings from characters to glyphs.
// There are many available formats, but we only support the Windows format 4 and 12, and format 14 as a supplement if available.
// This function returns a `CmapEncoding` object or null if no supported format could be found.
function parseCmapTable(data, start) {
    const cmap = {};
    cmap.version = parse.getUShort(data, start);
    check.argument(cmap.version === 0, 'cmap table version should be 0.');

    // The cmap table can contain many sub-tables, each with their own format.
    // We're only interested in a "platform 0" (Unicode format) and "platform 3" (Windows format) table,
    // 
    cmap.numTables = parse.getUShort(data, start + 2);
    let format14Parser = null;
    let format14offset = -1;
    let offset = -1;
    let platformId = null;
    let encodingId = null;
    const platform0Encodings = [0,1,2,3,4,6];
    const platform3Encodings = [0,1,10];
    for (let i = cmap.numTables - 1; i >= 0; i -= 1) {
        platformId = parse.getUShort(data, start + 4 + (i * 8));
        encodingId = parse.getUShort(data, start + 4 + (i * 8) + 2);
        if ((platformId === 3 && platform3Encodings.includes(encodingId)) ||
            (platformId === 0 && platform0Encodings.includes(encodingId)) ||
            (platformId === 1 && encodingId === 0) // MacOS <= 9
        ) {
            // only use the first supported table
            if (offset > 0) continue;
            offset = parse.getULong(data, start + 4 + (i * 8) + 4);
            // allow for early break
            if (format14Parser) {
                break;
            }
        } else if (platformId === 0 && encodingId === 5) {
            format14offset = parse.getULong(data, start + 4 + (i * 8) + 4);
            format14Parser = new parse.Parser(data, start + format14offset);
            if (format14Parser.parseUShort() !== 14) {
                format14offset = -1;
                format14Parser = null;
            } else if (offset > 0) {
                // we already got the regular table, early break
                break;
            }
        }
    }

    if (offset === -1) {
        // There is no cmap table in the font that we support.
        throw new Error('No valid cmap sub-tables found.');
    }

    const p = new parse.Parser(data, start + offset);
    cmap.format = p.parseUShort();

    if (cmap.format === 0) {
        parseCmapTableFormat0(cmap, p, platformId, encodingId);
    } else if (cmap.format === 12 || cmap.format === 13) {
        parseCmapTableFormat12or13(cmap, p, cmap.format);
    } else if (cmap.format === 4) {
        parseCmapTableFormat4(cmap, p, data, start, offset);
    } else {
        throw new Error(
            'Only format 0 (platformId 1, encodingId 0), 4, 12 and 14 cmap tables are supported ' +
            '(found format ' + cmap.format + ', platformId ' + platformId + ', encodingId ' + encodingId + ').'
        );
    }

    // format 14 is the only one that's not exclusive but can be used as a supplement.
    if (format14Parser) {
        parseCmapTableFormat14(cmap, format14Parser);
    }

    return cmap;
}

function addSegment(segments, code, glyphIndex) {
    segments.push({
        end: code,
        start: code,
        delta: -(code - glyphIndex),
        offset: 0,
        glyphIndex: glyphIndex
    });
}

function addTerminatorSegment(t) {
    t.segments.push({
        end: 0xFFFF,
        start: 0xFFFF,
        delta: 1,
        offset: 0
    });
}

function mergeSegments(segments) {
    if (segments.length === 0) return segments;
    const merged = [segments[0]];
    for (let i = 1; i < segments.length; i++) {
        const prev = merged[merged.length - 1];
        const curr = segments[i];
        if (
            prev.end + 1 === curr.start &&
            prev.delta === curr.delta &&
            curr.end !== 0xFFFF
        ) {
            prev.end = curr.end;
        } else {
            merged.push(curr);
        }
    }
    return merged;
}

// The Format 4 length field is a USHORT, capping the subtable at 65535 bytes.
// Each segment contributes 8 bytes (one entry in each of the four parallel arrays),
// plus the 14-byte header and the 2-byte reservedPad, leaving room for at most
// floor((65535 - 16) / 8) = 8189 segments before overflow.
const CMAP4_MAX_SEGMENTS = 8189;

// Make cmap table, format 4 by default, 12 if needed only
function makeCmapTable(glyphs) {
    // Plan 0 is the base Unicode Plan but emojis, for example are on another plan, and needs cmap 12 format (with 32bit)
    let isPlan0Only = true;
    let i;

    // Check if we need to add cmap format 12 or if format 4 only is fine
    for (i = glyphs.length - 1; i > 0; i -= 1) {
        const g = glyphs.get(i);
        if (g.unicode > 65535) {
            isPlan0Only = false;
            break;
        }
    }

    // Create the CMAP table with some values that still need calculation missing.
    let cmapTable = [
        {name: 'version', type: 'USHORT', value: 0},
        {name: 'numTables', type: 'USHORT', value: null},

        // CMAP 4 header
        {name: 'platformID', type: 'USHORT', value: 3},
        {name: 'encodingID', type: 'USHORT', value: 1},
        {name: 'offset', type: 'ULONG', value: null}
    ];

    // Build and merge segments up front so we can measure the true segment count
    // before committing to a table layout.
    const allSegments = [];
    for (i = 0; i < glyphs.length; i += 1) {
        const glyph = glyphs.get(i);
        for (let j = 0; j < glyph.unicodes.length; j += 1) {
            addSegment(allSegments, glyph.unicodes[j], i);
        }
    }
    allSegments.sort(function(a, b) { return a.start - b.start; });
    const mergedSegments = mergeSegments(allSegments);

    // Count BMP segments (those that fit in Format 4).  If after merging the
    // count still exceeds what a USHORT length field can encode, Format 4 cannot
    // represent the full mapping without silent truncation.  In that case we fall
    // back to emitting Format 12 for all glyphs, keeping a minimal Format 4
    // subtable (terminator only) for parsers that require its presence.
    let bmpSegmentCount = 0;
    for (let i = 0; i < mergedSegments.length; i++)
        if(mergedSegments[i].start <= 0xFFFF)
            bmpSegmentCount++;
    const cmap4Overflows = bmpSegmentCount > CMAP4_MAX_SEGMENTS;
    isPlan0Only = isPlan0Only && !cmap4Overflows;

    // Fill in missing values in CMAP table
    cmapTable[1].value = isPlan0Only ? 1 : 2;
    cmapTable[4].value = isPlan0Only ? 12 : 20;

    if (!isPlan0Only)
        cmapTable.push(...[
            // CMAP 12 header
            {name: 'cmap12PlatformID', type: 'USHORT', value: 3}, // We encode only for PlatformID = 3 (Windows) because it is supported everywhere
            {name: 'cmap12EncodingID', type: 'USHORT', value: 10},
            {name: 'cmap12Offset', type: 'ULONG', value: 0}
        ]);

    cmapTable.push(...[
        // CMAP 4 Subtable
        {name: 'format', type: 'USHORT', value: 4},
        {name: 'cmap4Length', type: 'USHORT', value: 0},
        {name: 'language', type: 'USHORT', value: 0},
        {name: 'segCountX2', type: 'USHORT', value: 0},
        {name: 'searchRange', type: 'USHORT', value: 0},
        {name: 'entrySelector', type: 'USHORT', value: 0},
        {name: 'rangeShift', type: 'USHORT', value: 0}
    ]);

    const t = new table.Table('cmap', cmapTable);

    t.segments = mergedSegments;

    addTerminatorSegment(t);

    const segCount = t.segments.length;
    let segCountToRemove = 0;

    // CMAP 4
    // Set up parallel segment arrays.
    let endCounts = [];
    let startCounts = [];
    let idDeltas = [];
    let idRangeOffsets = [];
    let glyphIds = [];

    // CMAP 12
    let cmap12Groups = [];

    for (i = 0; i < segCount; i += 1) {
        const segment = t.segments[i];

        // CMAP 4: when the table would overflow, emit only the terminator segment
        // so that Format 4 remains structurally valid. All actual mappings are
        // carried by the Format 12 subtable in that case.
        if (segment.end <= 65535 && segment.start <= 65535 && !cmap4Overflows ||
            (cmap4Overflows && segment.end === 0xFFFF && segment.start === 0xFFFF)) {
            endCounts.push({name: 'end_' + i, type: 'USHORT', value: segment.end});
            startCounts.push({name: 'start_' + i, type: 'USHORT', value: segment.start});
            idDeltas.push({name: 'idDelta_' + i, type: 'SHORT', value: segment.delta});
            idRangeOffsets.push({name: 'idRangeOffset_' + i, type: 'USHORT', value: segment.offset});
            if (segment.glyphId !== undefined) {
                glyphIds.push({name: 'glyph_' + i, type: 'USHORT', value: segment.glyphId});
            }
        } else {
            // Skip Unicode > 65535 (16bit unsigned max) for CMAP 4, will be added in CMAP 12
            segCountToRemove += 1;
        }

        // CMAP 12
        // Skip Terminator Segment
        if (!isPlan0Only && segment.glyphIndex !== undefined) {
            cmap12Groups.push({name: 'cmap12Start_' + i, type: 'ULONG', value: segment.start});
            cmap12Groups.push({name: 'cmap12End_' + i, type: 'ULONG', value: segment.end});
            cmap12Groups.push({name: 'cmap12Glyph_' + i, type: 'ULONG', value: segment.glyphIndex});
        }
    }

    // CMAP 4 Subtable
    t.segCountX2 = (segCount - segCountToRemove) * 2;
    t.searchRange = Math.pow(2, Math.floor(Math.log((segCount - segCountToRemove)) / Math.log(2))) * 2;
    t.entrySelector = Math.log(t.searchRange / 2) / Math.log(2);
    t.rangeShift = t.segCountX2 - t.searchRange;

    for (let i = 0; i < endCounts.length; i++) {
        t.fields.push(endCounts[i]);
    }
    t.fields.push({name: 'reservedPad', type: 'USHORT', value: 0});
    for (let i = 0; i < startCounts.length; i++) {
        t.fields.push(startCounts[i]);
    }
    for (let i = 0; i < idDeltas.length; i++) {
        t.fields.push(idDeltas[i]);
    }
    for (let i = 0; i < idRangeOffsets.length; i++) {
        t.fields.push(idRangeOffsets[i]);
    }
    for (let i = 0; i < glyphIds.length; i++) {
        t.fields.push(glyphIds[i]);
    }

    t.cmap4Length = 14 + // Subtable header
        endCounts.length * 2 +
        2 + // reservedPad
        startCounts.length * 2 +
        idDeltas.length * 2 +
        idRangeOffsets.length * 2 +
        glyphIds.length * 2;

    if (!isPlan0Only) {
        // CMAP 12 Subtable
        const cmap12Length = 16 + // Subtable header
            cmap12Groups.length * 4;

        t.cmap12Offset = 12 + (2 * 2) + 4 + t.cmap4Length;
        t.fields.push(...[
            {name: 'cmap12Format', type: 'USHORT', value: 12},
            {name: 'cmap12Reserved', type: 'USHORT', value: 0},
            {name: 'cmap12Length', type: 'ULONG', value: cmap12Length},
            {name: 'cmap12Language', type: 'ULONG', value: 0},
            {name: 'cmap12nGroups', type: 'ULONG', value: cmap12Groups.length / 3}
        ]);

        for (let i = 0; i < cmap12Groups.length; i++) {
            t.fields.push(cmap12Groups[i]);
        }
        
    }

    return t;
}

export default { parse: parseCmapTable, make: makeCmapTable };

export { parseCmapTableFormat0, parseCmapTableFormat14, makeCmapTable };
