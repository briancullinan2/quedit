/*
  Copyright Dirk Lemstra https://github.com/dlemstra/magick-wasm.
  Licensed under the Apache License, Version 2.0.
*/

import { Drawables } from '@src/drawing/drawables';
import { DrawableTextInterlineSpacing } from '@src/drawing/drawable-text-interline-spacing';
import { IDrawable } from '@src/drawing/drawable';

describe('Drawables#textInterlineSpacing', () => {
    it('should add the drawable', () => {
        const drawables = new Drawables()
            .textInterlineSpacing(42);

        const drawable = (drawables as unknown as { _drawables: IDrawable[] })._drawables[0];
        expect(drawable).toBeInstanceOf(DrawableTextInterlineSpacing);

        const drawableTextInterlineSpacing = drawable as DrawableTextInterlineSpacing;
        expect(drawableTextInterlineSpacing.spacing).toBe(42);
    });
});
